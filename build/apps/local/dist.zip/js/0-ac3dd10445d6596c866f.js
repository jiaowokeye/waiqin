(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/AddContent/index.js":
/*!***************************************************************************!*\
  !*** c:/Users/Administrator/Desktop/模板/模板/src/routes/AddContent/index.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../../node_modules.asar/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.module.css */ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/AddContent/index.module.css");
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd-mobile */ "../../../../../../../../../../../../../Desktop/模板/模板/node_modules/antd-mobile/es/index.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }




var Item = antd_mobile__WEBPACK_IMPORTED_MODULE_2__["List"].Item;

function AddContent(props) {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    address: "",
    address_memo: "",
    authid: -7,
    birth_province_id: "0",
    birthday: "",
    connect_id: "",
    contact_tel: "",
    defined_fields: "",
    email: "",
    group_name: "",
    is_share: "1",
    link_cid: "",
    menuid: "",
    name: "",
    office_fax: "",
    parentid: "",
    phone: "",
    postcode: "",
    qq: "",
    rand: Math.random(),
    remark: "",
    school: "",
    sex: "0",
    tags: "",
    title: "",
    type: "2",
    weixin: ""
  }),
      _useState2 = _slicedToArray(_useState, 2),
      field = _useState2[0],
      setField = _useState2[1];

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(function () {
    // 设置导航标题
    HWH5.navTitle({
      title: '新建联系人'
    });
  }, [1]);
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["App"]
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["List"], {
    renderHeader: function renderHeader() {
      return '必填';
    },
    className: "my-list"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.name,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          name: value
        }));
      }
    })
  }, "\u59D3\u540D"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.phone,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          phone: value
        }));
      }
    })
  }, "\u624B\u673A"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.title,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          title: value
        }));
      }
    })
  }, "\u804C\u4F4D")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["List"], {
    renderHeader: function renderHeader() {
      return '选填';
    },
    className: "my-list"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.group_name,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          'group_name': value
        }));
      }
    })
  }, "\u90E8\u95E8"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.contact_tel,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          "contact_tel": value
        }));
      }
    })
  }, "\u7535\u8BDD"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.office_fax,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          "office_fax": value
        }));
      }
    })
  }, "\u4F20\u771F"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.email,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          "email": value
        }));
      }
    })
  }, "\u90AE\u7BB1"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.qq,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          "qq": value
        }));
      }
    })
  }, "QQ"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.weixin,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          'weixin': value
        }));
      }
    })
  }, "\u5FAE\u4FE1"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["input"],
    extra: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["InputItem"], {
      value: field.remark,
      onChange: function onChange(value) {
        return setField(_objectSpread({}, field, {}, {
          "remark": value
        }));
      }
    })
  }, "\u5907\u6CE8")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Item, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    type: "primary"
  }, "\u786E\u5B9A"))));
}

/* harmony default export */ __webpack_exports__["default"] = (function (props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(AddContent, props));
});

/***/ }),

/***/ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/AddContent/index.module.css":
/*!***********************************************************************************!*\
  !*** c:/Users/Administrator/Desktop/模板/模板/src/routes/AddContent/index.module.css ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"App":"AddContent_App__1R2X2","header":"AddContent_header__gjDJ1","itemtextarea":"AddContent_itemtextarea__R793B","listOne":"AddContent_listOne__1gm-G","listOneLeft":"AddContent_listOneLeft__2Wr-a","listOneRight":"AddContent_listOneRight__2nhun","listTwo":"AddContent_listTwo__2iRmj","listOneBottom":"AddContent_listOneBottom__3xb7U","contentHeader":"AddContent_contentHeader__ciea5","add":"AddContent_add__3PXCn"};

/***/ })

}]);