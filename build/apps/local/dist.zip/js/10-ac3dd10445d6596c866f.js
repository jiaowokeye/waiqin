(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/SelectContact/index.js":
/*!******************************************************************************!*\
  !*** c:/Users/Administrator/Desktop/模板/模板/src/routes/SelectContact/index.js ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "../../../../../../../../../../../../../Desktop/模板/模板/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../../../node_modules.asar/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.module.css */ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/SelectContact/index.module.css");
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _servers_comp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../servers/comp */ "../../../../../../../../../../../../../Desktop/模板/模板/src/servers/comp.js");
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd-mobile */ "../../../../../../../../../../../../../Desktop/模板/模板/node_modules/antd-mobile/es/index.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }





var CheckboxItem = antd_mobile__WEBPACK_IMPORTED_MODULE_4__["Checkbox"].CheckboxItem;
var Item = antd_mobile__WEBPACK_IMPORTED_MODULE_4__["List"].Item;

function SelectContact(props) {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]),
      _useState2 = _slicedToArray(_useState, 2),
      contactList = _useState2[0],
      setContactList = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]),
      _useState4 = _slicedToArray(_useState3, 2),
      selectArr = _useState4[0],
      setSelectArr = _useState4[1];

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    // 设置导航标题
    HWH5.navTitle({
      title: '选会见人'
    });
    getConnectionQuery();
  }, [1]);

  function _onChange(val) {
    console.log(val);
    var newSelect = selectArr.concat([]);

    if (newSelect.indexOf(val) !== -1) {
      newSelect.splice(newSelect.indexOf(val), 1);
    } else {
      newSelect.push(val);
    }

    setSelectArr(newSelect);
  }

  function selectContact(_x) {
    return _selectContact.apply(this, arguments);
  } // 获取客户联系人


  function _selectContact() {
    _selectContact = _asyncToGenerator(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(e) {
      var meetwithArr, meetwithNameArr, history;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              console.log(e);
              console.log(window.visitObj);
              meetwithArr = [];
              meetwithNameArr = [];
              selectArr.map(function (e) {
                meetwithArr.push(contactList[e]['user_id']);
                meetwithNameArr.push(contactList[e]['name']);
                return '';
              });
              window.visitObj['open_contact'] = meetwithArr.join(',');
              window.visitObj['meetwith'] = meetwithArr.join(',');
              window.visitObj['meetwithName'] = meetwithNameArr.join(',');
              history = props.history; //跳转内部页面并传值

              history.push({
                pathname: '/'
              });

            case 10:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));
    return _selectContact.apply(this, arguments);
  }

  function getConnectionQuery() {
    Object(_servers_comp__WEBPACK_IMPORTED_MODULE_3__["connectionQuery"])({
      link_cid: window.visitObj.customer_id,
      customer_connection_uid_type: 1,
      card_uid_type: 1,
      type: '2,3'
    }).then(function (res) {
      var data = res.data;
      var list = [];
      data.map(function (e) {
        list.push(_objectSpread({}, e, {}, {
          value: e.user_id
        }));
        return '';
      });
      setContactList(list);
    });
  }

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_2__["App"]
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_2__["listWrap"]
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_4__["List"], {
    renderHeader: function renderHeader() {
      return '会见人';
    }
  }, contactList.map(function (i, e) {
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Item, {
      extra: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, i.name, " ", i.group_name), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, i.phone))
    }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(CheckboxItem, {
      checked: selectArr.indexOf(e) !== -1 ? true : false,
      key: i.user_id,
      onChange: function onChange() {
        return _onChange(e);
      }
    }));
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Item, null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(antd_mobile__WEBPACK_IMPORTED_MODULE_4__["Button"], {
    type: "primary",
    onClick: selectContact
  }, "\u786E\u5B9A")))));
}

/* harmony default export */ __webpack_exports__["default"] = (function (props) {
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_2__["App"]
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SelectContact, props)));
});

/***/ }),

/***/ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/SelectContact/index.module.css":
/*!**************************************************************************************!*\
  !*** c:/Users/Administrator/Desktop/模板/模板/src/routes/SelectContact/index.module.css ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"App":"SelectContact_App__1vhKU","map":"SelectContact_map__10MRJ","header":"SelectContact_header__1D9EV","add":"SelectContact_add__20_mo","listItem":"SelectContact_listItem__u3zyd","listLeft":"SelectContact_listLeft__3pjvW","customer":"SelectContact_customer__2VGwt","address":"SelectContact_address__2TjKE","belong":"SelectContact_belong__1TZKR","listRight":"SelectContact_listRight__eATNx"};

/***/ }),

/***/ "../../../../../../../../../../../../../Desktop/模板/模板/src/servers/comp.js":
/*!****************************************************************!*\
  !*** c:/Users/Administrator/Desktop/模板/模板/src/servers/comp.js ***!
  \****************************************************************/
/*! exports provided: customerModify, customerFind, connectionQuery, visitAdd, getTree, getPlanList, getVisitList, addPlan */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customerModify", function() { return customerModify; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customerFind", function() { return customerFind; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "connectionQuery", function() { return connectionQuery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "visitAdd", function() { return visitAdd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTree", function() { return getTree; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPlanList", function() { return getPlanList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getVisitList", function() { return getVisitList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addPlan", function() { return addPlan; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "../../../../../../../../../../../../../Desktop/模板/模板/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../utils/request */ "../../../../../../../../../../../../../Desktop/模板/模板/src/utils/request.js");


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
 // 新增客户

function customerModify(_x) {
  return _customerModify.apply(this, arguments);
} // 客户列表

function _customerModify() {
  _customerModify = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", Object(_utils_request__WEBPACK_IMPORTED_MODULE_1__["default"])('comp/customer/basic.do?modify', params));

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _customerModify.apply(this, arguments);
}

function customerFind(_x2) {
  return _customerFind.apply(this, arguments);
} // 客户联系人

function _customerFind() {
  _customerFind = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            return _context2.abrupt("return", Object(_utils_request__WEBPACK_IMPORTED_MODULE_1__["default"])('comp/customer/basic.do?find', params));

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _customerFind.apply(this, arguments);
}

function connectionQuery(_x3) {
  return _connectionQuery.apply(this, arguments);
} // 拜访开始

function _connectionQuery() {
  _connectionQuery = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            return _context3.abrupt("return", Object(_utils_request__WEBPACK_IMPORTED_MODULE_1__["default"])('comp/connection/basic.do?query', params));

          case 1:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _connectionQuery.apply(this, arguments);
}

function visitAdd(_x4) {
  return _visitAdd.apply(this, arguments);
} // 获取人员树

function _visitAdd() {
  _visitAdd = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            return _context4.abrupt("return", Object(_utils_request__WEBPACK_IMPORTED_MODULE_1__["default"])('comp/customer/visit.do?add', params));

          case 1:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
  return _visitAdd.apply(this, arguments);
}

function getTree(_x5) {
  return _getTree.apply(this, arguments);
} // 获取计划列表

function _getTree() {
  _getTree = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee5(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            return _context5.abrupt("return", Object(_utils_request__WEBPACK_IMPORTED_MODULE_1__["default"])('comp/group.do?getTree', params));

          case 1:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5);
  }));
  return _getTree.apply(this, arguments);
}

function getPlanList(_x6) {
  return _getPlanList.apply(this, arguments);
} // 获取拜访列表

function _getPlanList() {
  _getPlanList = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee6(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            return _context6.abrupt("return", Object(_utils_request__WEBPACK_IMPORTED_MODULE_1__["default"])('customer/visit/plan.do?find', params));

          case 1:
          case "end":
            return _context6.stop();
        }
      }
    }, _callee6);
  }));
  return _getPlanList.apply(this, arguments);
}

function getVisitList(_x7) {
  return _getVisitList.apply(this, arguments);
} // 新增计划

function _getVisitList() {
  _getVisitList = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee7(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            return _context7.abrupt("return", Object(_utils_request__WEBPACK_IMPORTED_MODULE_1__["default"])('comp/customer/visit.do?findDetail', params));

          case 1:
          case "end":
            return _context7.stop();
        }
      }
    }, _callee7);
  }));
  return _getVisitList.apply(this, arguments);
}

function addPlan(_x8) {
  return _addPlan.apply(this, arguments);
}

function _addPlan() {
  _addPlan = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee8(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            return _context8.abrupt("return", Object(_utils_request__WEBPACK_IMPORTED_MODULE_1__["default"])('customer/visit/plan.do?add', params));

          case 1:
          case "end":
            return _context8.stop();
        }
      }
    }, _callee8);
  }));
  return _addPlan.apply(this, arguments);
}

/***/ })

}]);