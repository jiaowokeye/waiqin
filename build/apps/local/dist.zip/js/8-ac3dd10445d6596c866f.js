(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[8],{

/***/ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/Map/index.js":
/*!********************************************************************!*\
  !*** c:/Users/Administrator/Desktop/模板/模板/src/routes/Map/index.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../../../node_modules.asar/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.module.css */ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/Map/index.module.css");
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_1__);
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }




function MapApp(props) {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null),
      _useState2 = _slicedToArray(_useState, 2),
      map = _useState2[0],
      setMap = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null),
      _useState4 = _slicedToArray(_useState3, 2),
      locationData = _useState4[0],
      setLocationData = _useState4[1];

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(function () {
    getLocation(); // 设置导航标题

    HWH5.navTitle({
      title: '当前位置'
    });
  }, [1]);

  function getLocation() {
    HWH5.getLocation({
      type: 1
    }).then(function (data) {
      setLocationData(data);
      console.log(data.address);
      var mapObj = new window.AMap.Map('map', {
        zoom: 11,
        //级别
        center: [data.latitude, data.longitude] //中心点坐标

      });
      setMap(mapObj);
    }).catch(function (error) {
      console.log('获取位置信息异常', error);
    });
  }

  console.log(map);
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["App"]
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["header"]
  }, locationData ? locationData.address : ''), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    id: "map",
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["map"]
  }));
}

/* harmony default export */ __webpack_exports__["default"] = (function (props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: _index_module_css__WEBPACK_IMPORTED_MODULE_1__["App"]
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(MapApp, props)));
});

/***/ }),

/***/ "../../../../../../../../../../../../../Desktop/模板/模板/src/routes/Map/index.module.css":
/*!****************************************************************************!*\
  !*** c:/Users/Administrator/Desktop/模板/模板/src/routes/Map/index.module.css ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"App":"Map_App__2t-X2","map":"Map_map__5RBR9","header":"Map_header__2JNrR"};

/***/ })

}]);